package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.servlet.ModelAndView;

import com.model.Product;
import com.service.ProductService;

@RestController
@RequestMapping("product")
@CrossOrigin(origins = {"http://localhost:3000","http://10.231.139.106:3000"})
public class ProductController {
	@Autowired
	ProductService productService;
	@GetMapping
	public ResponseEntity <List<Product>> getProduct() {
		System.out.println("Get All Products Called");
		List<Product> allProducts=productService.getProducts();
		System.out.println(allProducts);
		return new ResponseEntity<List<Product>>(allProducts,HttpStatus.OK);
	}
	/*
	 * @RequestMapping("/productSave") public ModelAndView getProduct(Product
	 * product) { System.out.println("Controller:"+product);
	 * productService.addProduct(product); return new
	 * ModelAndView("productSave","prod",product); }
	 */
	@GetMapping("/{productId}")
	public ResponseEntity<Product> getProductOrder(@PathVariable("productId")int productId) {
		System.out.println("Product called "+productId);
		Product product=new Product();
		if(productService.isProductExist(productId)) {
			product=productService.getProduct(productId);
			return new ResponseEntity<Product>(product,HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Product>(product,HttpStatus.NO_CONTENT);
		}
	} 
	@DeleteMapping("/{productId}")
	public  ResponseEntity<Product> deleteProduct(@PathVariable("productId")int productId) {
		if(productService.isProductExist(productId)) {
			productService.deleteProduct(productId);
			return new ResponseEntity<Product>(HttpStatus.NO_CONTENT);
		}
		else {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
	}
	@PostMapping
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		System.out.println("Add Product Called");
		if(productService.isProductExist(product.getProductId())) {
			System.out.println(product);
			return new ResponseEntity<Product>(HttpStatus.CONFLICT);
		}
		else {
			productService.addProduct(product);
			return new ResponseEntity<Product>(HttpStatus.CREATED);
		}
		
	}
	@PutMapping
	public ResponseEntity<Product> updateProduct(@RequestBody Product product) {
		System.out.println("Update Product Called");
		if(productService.isProductExist(product.getProductId())) {
			productService.updateProduct(product);
			System.out.println(product);
			return new ResponseEntity<Product>(HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Product>(HttpStatus.CONFLICT);
		} 
	}
}