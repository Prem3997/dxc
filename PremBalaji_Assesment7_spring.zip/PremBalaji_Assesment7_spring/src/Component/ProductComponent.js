import React, { Component } from 'react';
import ProductDataService from '../Service/ProductDataService'
import { Formik, Form,Field, ErrorMessage } from 'formik';



class ProductComponent extends Component {
    constructor(props){
        super(props)
        this.state=({
            productId: this.props.match.params.productId,
            productName:"",
            quantityOnHand:"",
            price:""
        })
        this.onSubmit=this.onSubmit.bind(this)
    }
    componentWillMount(){
        if(this.state.productId===-1)
            return -1
        ProductDataService.getProduct(this.state.productId).then(
            response=>{
                this.setState({
                    productName:response.data.productName,
                    quantityOnHand:response.data.quantityOnHand,
                    price:response.data.price
                })
            }
        )
    }
    onSubmit(product){
        console.log(product)
        console.log(this.state.productId)
        console.log(product.productId)
        if(this.state.productId==='-1'){
            ProductDataService.addProduct(product).then(()=>this.props.history.push('/products'))
        }
        else if(this.state.productId==='0'){
            ProductDataService.getProductByName(product.productName).then(()=>this.props.history.push('/products'))
        }
        else{
            ProductDataService.updateProduct(product).then(()=>this.props.history.push('/products'))
        }  
    }
    validProductForm(values){
        let error={}
        if(!values.productId){
            error.productId="Enter Product Id"
        }
        if(!values.productName){
            error.productName="Enter Product Name"
        }
        if(this.productId==0){
            if(!values.quantityOnHand){
                error.quantityOnHand="Enter Product Quantity"
            }
        }
        if(this.productId==0){
            if(!values.price){
                error.price="Enter Product Price"
            }
        }
        console.log(error)
        return error
    }
    render() {
        let {
            productId,productName,quantityOnHand,price
        }=this.state
        let Field1,Button1,label1,labelProductQuantiy,labelPrice,FieldProductQuanity,FieldPrice
        if(productId<0){
            label1=<label>Product Id</label>
            Field1=<Field className="form-control" type="text" name="productId" ></Field>
            labelProductQuantiy=<label>Product Quantity</label>
            FieldProductQuanity=<Field className="form-control" type="text" name="quantityOnHand"></Field>
            labelPrice=<label>Product Price</label>
            FieldPrice=<Field className="form-control" type="text" name="price"></Field>
            Button1=<button className="btn btn-success" type="submit">Add</button>
        }
        if(productId>0){
            label1=<label>Product Id</label>
            Field1=<Field className="form-control" type="text" name="productId" disabled></Field>
            labelProductQuantiy=<label>Product Quantity</label>
            FieldProductQuanity=<Field className="form-control" type="text" name="quantityOnHand"></Field>
            labelPrice=<label>Product Price</label>
            FieldPrice=<Field className="form-control" type="text" name="price"></Field>
            Button1=<button className="btn btn-success" type="submit">Save</button>
        }
        if(productId==0){
            Button1=<button className="btn btn-success" type="submit">Search</button>
        }
        return (
            <div align>
                <h1 align="center">To ADD/UPDATE The Product</h1>
                <Formik
                initialValues={{productId,productName,quantityOnHand,price}} enableReinitialize={true}
                onSubmit={this.onSubmit}
                validateOnChange={false}
                validateOnBlur={false}
                validate={this.validProductForm}>
                    <Form>
                        <fieldset className="form-group">
                            {label1}
                            {Field1}
                        </fieldset>
                        <fieldset className="form-group">
                            <label>Product Name</label>
                            <Field className="form-control" type="text" name="productName"></Field>
                        </fieldset>
                        <fieldset className="form-group">
                            {labelProductQuantiy}
                            {FieldProductQuanity}
                        </fieldset>
                        <fieldset className="form-group">
                            {labelPrice}
                            {FieldPrice}
                        </fieldset>
                        <ErrorMessage name="productName" component="div" className="alert alert-warning"/>
                        <ErrorMessage name="quantityOnHand" component="div" className="alert alert-warning"/>
                        <ErrorMessage name="price" component="div" className="alert alert-warning"/>
                        
                        {Button1}
                    </Form>
                </Formik>
            </div>
        );
    }
}

export default ProductComponent;