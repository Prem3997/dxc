package com.msn;

import org.testng.annotations.Test;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class MsnTestCase {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void Testcase5() throws InterruptedException{
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver();
		driver.get("https://www.msn.com/en-in");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		Set<String> windowHandles = driver.getWindowHandles();
		Iterator<String> i=windowHandles.iterator();
		String msn=i.next();
		String onenote=i.next();
		driver.switchTo().window(onenote);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("9988776655");
		Thread.sleep(3000);
		driver.close();
		driver.switchTo().window(msn);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		Thread.sleep(3000);
		driver.quit();
		}
	}
}
