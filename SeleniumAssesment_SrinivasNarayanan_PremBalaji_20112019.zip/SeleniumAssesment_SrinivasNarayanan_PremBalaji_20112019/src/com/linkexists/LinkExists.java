package com.linkexists;

import org.testng.annotations.Test;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class LinkExists {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase6() throws InterruptedException{
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");//we do this instead of setting system variables
			driver=new ChromeDriver(); //OpenBrowser
		}
		driver.get("https://in.yahoo.com/?p=us");
		driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		List<WebElement> findElements = driver.findElements(By.tagName("a"));
		for(int i=0;i<findElements.size();i++){
			if(findElements.get(i).getText().equalsIgnoreCase("News")){
				System.out.println("Exists");
				break;
			}
		}
	}
}

