package com.actitime;

import org.testng.annotations.Test;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class ActitimeTestCase {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void Testcase1(){
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver();
		driver.get("http://localhost:9000/login.do");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		driver.findElement(By.xpath("//a[@class='content tasks']//img[@class='sizer']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Projects & Customers')]")).click();
		driver.findElement(By.xpath("//body/div[@id='container']/form[@id='customersProjectsForm']/table[@class='mainContentPadding rightPadding']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/input[2]")).click();
		driver.findElement(By.xpath("//select[@name='customerId']")).sendKeys("CustomerA");
		driver.findElement(By.xpath("//input[@name='name']")).sendKeys("ProjectA");
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("DescriptionA");
		driver.findElement(By.xpath("//input[@id='active_projects_action']")).click();
		driver.findElement(By.xpath("//input[@name='createProjectSubmit']")).click();
		try{
			driver.findElement(By.xpath("//span[@class='successmsg']")).isDisplayed();
			driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
			
		}catch(Throwable t){
			Assert.fail("success message not dispalyed");
			driver.findElement(By.xpath("//table[@class='rightPadding']//input[2]")).click();
			Alert alert=driver.switchTo().alert();
			alert.accept();
			driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
		}
		driver.quit();
		st.assertAll();
		}
	}
	@Test
	public void Testcase2(){
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver();
		driver.get("http://localhost:9000/login.do");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		driver.findElement(By.xpath("//a[@class='content tasks']//img[@class='sizer']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Projects & Customers')]")).click();
		driver.findElement(By.xpath("//body/div[@id='container']/form[@id='customersProjectsForm']/table[@class='mainContentPadding rightPadding']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/input[2]")).click();
		driver.findElement(By.xpath("//select[@name='customerId']")).sendKeys("CustomerA");
		driver.findElement(By.xpath("//input[@name='name']")).sendKeys("ProjectB");
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("DescriptionB");
		driver.findElement(By.xpath("//input[@id='add_tasks_action']")).click();
		driver.findElement(By.xpath("//input[@name='createProjectSubmit']")).click();
		try{
			driver.findElement(By.xpath("//span[@class='successmsg']")).isDisplayed();
			driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
			
		}catch(Throwable t){
			Assert.fail("success message not dispalyed");
			driver.findElement(By.xpath("//table[@class='rightPadding']//input[2]")).click();
			Alert alert=driver.switchTo().alert();
			alert.accept();
			driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
		}
		driver.quit();
		st.assertAll();
		}
	}
	@Test
	public void Testcase3(){
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver();
		driver.get("http://localhost:9000/login.do");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		driver.findElement(By.xpath("//a[@class='content tasks']//img[@class='sizer']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Projects & Customers')]")).click();
		driver.findElement(By.xpath("//body/div[@id='container']/form[@id='customersProjectsForm']/table[@class='mainContentPadding rightPadding']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/input[2]")).click();
		driver.findElement(By.xpath("//select[@name='customerId']")).sendKeys("CustomerA");
		driver.findElement(By.xpath("//input[@name='name']")).sendKeys("ProjectC");
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("DescriptionC");
		driver.findElement(By.xpath("//input[@id='add_more_projects']")).click();
		driver.findElement(By.xpath("//input[@name='createProjectSubmit']")).click();
		try{
			driver.findElement(By.xpath("//span[@class='successmsg']")).isDisplayed();
			driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
			
		}catch(Throwable t){
			Assert.fail("success message not dispalyed");
			driver.findElement(By.xpath("//table[@class='rightPadding']//input[2]")).click();
			Alert alert=driver.switchTo().alert();
			alert.accept();
			driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
		}
		driver.quit();
		st.assertAll();
		}
	}
}
