package com.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.ProductDao;
import com.model.Product;

public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao productDao;
	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		System.out.println("Service:"+product);
		String productName=product.getProductName();
		productName="(AMAZON)"+productName;
		product.setProductName(productName);
		productDao.addProduct(product);
		return false;
	}

}
