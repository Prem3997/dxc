package com.dao;

import com.model.Product;

public interface ProductDao {
	public boolean addProduct(Product product);
}
