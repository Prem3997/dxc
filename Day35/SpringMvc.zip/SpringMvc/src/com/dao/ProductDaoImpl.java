package com.dao;

import com.model.Product;

public class ProductDaoImpl implements ProductDao {
	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		System.out.println("DAO:"+product);
		return false;
	}

}
