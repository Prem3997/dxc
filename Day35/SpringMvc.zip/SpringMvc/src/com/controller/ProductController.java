package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.model.Product;
import com.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	@RequestMapping("/productSave")
	public ModelAndView getProduct(Product product) {
		System.out.println("Controller:"+product);
		productService.addProduct(product);
		return new ModelAndView("productSave","prod",product);
	}
}