package com.dxc.quiz.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dxc.quiz.dbconn.DbConnection;
import com.dxc.quiz.model.Questions;


public class quizDaoImpl implements quizDao{
	Connection connection=DbConnection.getConnection();
	List<Questions> questionList=new ArrayList<Questions>();
	private static final String GET_RANDOM_QUESTION="Select *from quiz ORDER by RAND() LIMIT 3";
	@Override
	public List<Questions> getQuestions() {
		// TODO Auto-generated method stub
		Statement statement;
		try {
			statement = connection.createStatement();
			ResultSet resultSet=statement.executeQuery(GET_RANDOM_QUESTION);
			while(resultSet.next()) {
				Questions questions=new Questions();
				questions.setQuestionId(resultSet.getInt(1));
				questions.setQuestion(resultSet.getString(2));
				questions.setAnswer(resultSet.getString(3));
				questionList.add(questions);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return questionList;
	}

}
