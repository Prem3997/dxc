package com.dxc.quiz.dao;

import java.util.List;

import com.dxc.quiz.model.Questions;

public interface quizDao {
	public List<Questions> getQuestions();
}
