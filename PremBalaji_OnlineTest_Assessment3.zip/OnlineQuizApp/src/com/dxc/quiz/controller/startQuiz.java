package com.dxc.quiz.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.dxc.quiz.dao.quizDao;
import com.dxc.quiz.dao.quizDaoImpl;
import com.dxc.quiz.model.Questions;

/**
 * Servlet implementation class startQuiz
 */
public class startQuiz extends HttpServlet implements HttpSessionListener {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public startQuiz() {
        super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	quizDao dao=new quizDaoImpl();
    	List<Questions>questionsList=dao.getQuestions();
    	HttpSession httpSession=request.getSession();
    	httpSession.setAttribute("Question1", questionsList.get(0).getQuestion());
    	httpSession.setAttribute("Question2", questionsList.get(1).getQuestion());
    	httpSession.setAttribute("Question3", questionsList.get(2).getQuestion());
    	httpSession.setAttribute("Answer1", questionsList.get(0).getAnswer());
    	httpSession.setAttribute("Answer2", questionsList.get(1).getAnswer());
    	httpSession.setAttribute("Answer3", questionsList.get(2).getAnswer());
    	RequestDispatcher dispatcher=request.getRequestDispatcher("Questions1.jsp");
    	dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher;
		HttpSession httpSession=request.getSession();
		String TrueAnswer1=(String) httpSession.getAttribute("Answer1");
		String answer1=request.getParameter("answer");
		String answer2=request.getParameter("answer");
		String TrueAnswer2=(String) httpSession.getAttribute("Answer2");
		String answer3=request.getParameter("answer");
		String TrueAnswer3=(String) httpSession.getAttribute("Answer3");
		dispatcher=request.getRequestDispatcher("Results.jsp");
		int marks=0;
		if(answer1.equals(TrueAnswer1))
			marks=marks+1;
		if(answer2.equals(TrueAnswer2))
			marks=marks+1;
		if(answer3.equals(TrueAnswer3))
			marks=marks+1;
		System.out.println(marks);
		httpSession.setAttribute("marks", marks);
		dispatcher.forward(request, response);
	}
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		// TODO Auto-generated method stub
		HttpSession session=se.getSession();
		System.out.println("Session Created"+session.getId());
		session.setMaxInactiveInterval(10);
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		// TODO Auto-generated method stub
		System.out.println("Session Destroyed");
	}

}
