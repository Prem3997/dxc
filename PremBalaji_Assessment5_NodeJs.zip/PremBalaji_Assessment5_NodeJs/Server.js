var express=require("express")
var fs=require("fs")
var aboutData=fs.readFileSync("./resources/about.txt","utf-8")
console.log(aboutData)
var app=express()
app.set("view engine","ejs")

app.get("/about",function(request,response){
    response.render("about",
    {aboutCompany:aboutData})
})
app.listen(8000)
console.log("Server Started at 8000")