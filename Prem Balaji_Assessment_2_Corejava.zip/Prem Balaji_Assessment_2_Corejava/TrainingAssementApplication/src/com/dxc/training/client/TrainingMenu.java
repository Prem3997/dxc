package com.dxc.training.client;

import java.util.Scanner;

import com.dxc.training.dao.TrainingDAO;
import com.dxc.training.dao.TrainingDAOImpl;

public class TrainingMenu {
	Scanner scanner=new Scanner(System.in);
	int choice;
	TrainingDAO trainingDAO;
	public TrainingMenu() {
		// TODO Auto-generated constructor stub
		this.trainingDAO=new TrainingDAOImpl();
	}
	public void launchMenu() {
		while(true) {
			System.out.println("Menu");
			System.out.println("1.Display All Records");
			System.out.println("2.Display Records one by one and Update Percentage");
			System.out.println("3.Exit");
			System.out.println("Enter the choice");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println(trainingDAO.getAllRecords());
				break;
			case 2:
				trainingDAO.updatePercentage();
				break;
			case 3:
				System.out.println("Program Ended");
				System.exit(0);
				break;
			}
		}
	}
}
