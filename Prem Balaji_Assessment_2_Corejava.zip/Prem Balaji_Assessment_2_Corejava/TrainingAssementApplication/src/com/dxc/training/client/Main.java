package com.dxc.training.client;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserLogin login=new UserLogin();
		login.validateUser();
		TrainingMenu menu=new TrainingMenu();
		menu.launchMenu();

	}

}
