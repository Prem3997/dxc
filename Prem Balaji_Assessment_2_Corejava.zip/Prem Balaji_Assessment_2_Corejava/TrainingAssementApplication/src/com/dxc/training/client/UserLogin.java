package com.dxc.training.client;

import java.util.Scanner;

import com.dxc.training.dao.UserDAO;
import com.dxc.training.dao.UserDAOImp;
import com.dxc.training.model.User;

public class UserLogin {
	Scanner scanner=new Scanner(System.in);
	UserDAO userDAO;
	String userName;
	String password;
	public UserLogin() {
		// TODO Auto-generated constructor stub
		this.userDAO=new UserDAOImp();
	}	
	public void validateUser() {
		// TODO Auto-generated method stub
		System.out.println("Enter UserId and Password");
		userName=scanner.next();
		password=scanner.next();
		User user=new User(userName,password);
		if(userDAO.validateUser(user)) {
			System.out.println("Login Success");
		}
		else {
			System.out.println("Incorrect Credentials");
		}
	}
}
