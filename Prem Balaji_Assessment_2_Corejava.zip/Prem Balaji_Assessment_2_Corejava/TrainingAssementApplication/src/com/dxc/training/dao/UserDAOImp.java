package com.dxc.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.training.dbconn.DbConnection;
import com.dxc.training.model.User;

public class UserDAOImp implements UserDAO{
	Connection connection=DbConnection.getConnection();
	private static final String Fetch_User="Select * from users where Username=? and Password =?";
	@Override
	public boolean validateUser(User user) {
		// TODO Auto-generated method stub
		boolean validUser=false;
		PreparedStatement preparedStatement;
		try {
			preparedStatement=connection.prepareStatement(Fetch_User);
			preparedStatement.setString(1,user.getUserName());
			preparedStatement.setString(2,user.getPassword());
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				validUser=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return validUser;
	}

}
