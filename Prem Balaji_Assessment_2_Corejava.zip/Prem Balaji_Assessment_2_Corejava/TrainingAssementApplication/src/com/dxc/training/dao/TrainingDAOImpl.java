package com.dxc.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dxc.training.dbconn.DbConnection;
import com.dxc.training.model.Training;

public class TrainingDAOImpl implements TrainingDAO {
	Scanner scanner=new Scanner(System.in);
	int Percentage;
	Connection connection=DbConnection.getConnection();
	private static final String FETCH_ALL_RECORDS="Select * from training";
	private static final String UPDATE_PERCENTAGE="Update training set percentage=? where sapId=?";
	@Override
	public List<Training> getAllRecords() {
		// TODO Auto-generated method stub
		List<Training> allRecords=new ArrayList<Training>();
		try {
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(FETCH_ALL_RECORDS);
			while(resultSet.next()) {
				Training training=new Training();
				training.setSapId(resultSet.getString(1));
				training.setEmployeeName(resultSet.getString(2));
				training.setStream(resultSet.getString(3));
				training.setPercentage(resultSet.getInt(4));
				allRecords.add(training);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return allRecords;
	}
	@Override
	public void updatePercentage() {
		// TODO Auto-generated method stub
		try {
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(FETCH_ALL_RECORDS);
			PreparedStatement preparedStatement;
			while(resultSet.next()) {
				System.out.println("SapId: "+resultSet.getString(1));
				System.out.println("Employee Name: "+resultSet.getString(2));
				System.out.println("Stream: "+resultSet.getString(3));
				if(resultSet.getInt(4)==0) {
					System.out.println("Enter The Percentage ");
					Percentage=scanner.nextInt();
					preparedStatement=connection.prepareStatement(UPDATE_PERCENTAGE);
					preparedStatement.setInt(1, Percentage);
					preparedStatement.setString(2,resultSet.getString(1));
					preparedStatement.executeUpdate();
				}
				else {
					System.out.println("Percentage: "+resultSet.getInt(4));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}
