package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.model.Product;
import com.mongodb.WriteResult;
@Repository
public class ProductDaoImpl implements ProductDao {
	@Autowired
	MongoTemplate mongoTemplate;
	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		System.out.println("DAO:"+product);
		mongoTemplate.save(product);
		return false;
	}

	/*
	 * @Override public Product getProduct() { // TODO Auto-generated method stub
	 * Product product=new Product(1001, "OnePlus", 45, 35000); return product; }
	 */

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return mongoTemplate.findById(productId, Product.class,"product");
	}

	@Override
	public boolean isProductExist(int productId) {
		// TODO Auto-generated method stub
		Product product=mongoTemplate.findById(productId, Product.class, "product");
		if(product==null)
			return false;
		else
			return true;
	}

	@Override
	public boolean deleteProduct(int productId) {
		// TODO Auto-generated method stub
		Product product=getProduct(productId);
		WriteResult deleteResult=mongoTemplate.remove(product);
		System.out.println(deleteResult);
		int rowsAffected=deleteResult.getN();
		if(rowsAffected==0)
			return false;
		else
			return true;
	}

	@Override
	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		mongoTemplate.save(product);	
		return false;
	}

	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(Product.class);
	}

	@Override
	public List<Product> getProductsByName(String productName) {
		// TODO Auto-generated method stub
		return null;
	}

}
