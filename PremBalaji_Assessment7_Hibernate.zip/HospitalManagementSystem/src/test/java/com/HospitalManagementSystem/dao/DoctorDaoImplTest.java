package com.HospitalManagementSystem.dao;

import java.util.ArrayList;
import java.util.List;

import com.HospitalManagementSystem.model.Doctor;
import com.HospitalManagementSystem.model.Hospital;

import junit.framework.TestCase;

public class DoctorDaoImplTest extends TestCase {
	DoctorDaoImpl daoImpl;
	private List<Hospital> hospitalList=new ArrayList<Hospital>();
	private List<Hospital> updatehospitalList=new ArrayList<Hospital>();
	private List<Doctor> getDoctorName=new ArrayList<Doctor>();
	private List<Doctor> getDoctorName1=new ArrayList<Doctor>();
	@Override
	protected void setUp() throws Exception {
		// TODO Auto-generated method stub
		super.setUp();
		daoImpl=new DoctorDaoImpl();
	}
	
	public void testGetDoctor() {
		Hospital details=new Hospital("PremHospital", "Bangalore");
		hospitalList.add(details);
		Doctor doctor=new Doctor("1001", "Prem", 1001, hospitalList);
		daoImpl.addDoctor(doctor);
		Doctor getDoctor=daoImpl.getDoctor("1001");
		System.out.println(getDoctor);
		System.out.println(doctor);
		assertEquals(getDoctor,doctor);
	}

	public void testGetAllDoctors() {
		List<Doctor> allDoctor1=daoImpl.getAllDoctors();
		Hospital details=new Hospital("111", "1111");
		hospitalList.add(details);
		Doctor doctor=new Doctor("223", "2424", 1324, hospitalList);
		daoImpl.addDoctor(doctor);
		List<Doctor> allDoctor2=daoImpl.getAllDoctors();
		assertEquals(allDoctor2.size(), allDoctor1.size()+1);
		
	}

	public void testAddDoctor() {
		List<Doctor> allDoctor1=daoImpl.getAllDoctors();
		Hospital details=new Hospital("111", "1111");
		hospitalList.add(details);
		Doctor doctor=new Doctor("22ee3", "2424", 1324, hospitalList);
		daoImpl.addDoctor(doctor);
		List<Doctor> allDoctor2=daoImpl.getAllDoctors();
		assertNotSame(allDoctor1.size(), allDoctor2.size());
	}

	public void testDeleteDoctor() {
		Hospital details=new Hospital("111", "1111");
		hospitalList.add(details);
		Doctor doctor=new Doctor("22eeere3", "2424", 1324, hospitalList);
		daoImpl.addDoctor(doctor);
		List<Doctor> allDoctor1=daoImpl.getAllDoctors();
		daoImpl.deleteDoctor("22eeere3");
		List<Doctor> allDoctor2=daoImpl.getAllDoctors();
		assertNotSame(allDoctor1.size(), allDoctor2.size());
	}

	public void testUpdateDoctor() {
		Hospital details=new Hospital("111", "1111");
		hospitalList.add(details);
		Doctor doctor=new Doctor("23rre3", "2424", 1324, hospitalList);
		daoImpl.addDoctor(doctor);
		Hospital updateDetails=new Hospital("111", "1111");
		updatehospitalList.add(updateDetails);
		Doctor updateDoctor=new Doctor("23rre3", "2424e", 1324, updatehospitalList);
		daoImpl.updateDoctor(updateDoctor);
		Doctor getDoctor=daoImpl.getDoctor("23rre3");
		assertEquals(getDoctor.getName(), updateDoctor.getName());
		
	}

	public void testIsDoctorExists() {
		Hospital details=new Hospital("111", "1111");
		hospitalList.add(details);
		Doctor doctor=new Doctor("2356re3", "2424", 1324, hospitalList);
		daoImpl.addDoctor(doctor);
		boolean isDoctor=daoImpl.isDoctorExists("2356re3");
		assertEquals(true, isDoctor);
	}

	public void testGetDoctorByName() {
		Hospital details=new Hospital("111", "1111");
		hospitalList.add(details);
		Doctor doctor=new Doctor("3483989", "Roshan", 1324, hospitalList);
		daoImpl.addDoctor(doctor);
		getDoctorName1.add(doctor);
		getDoctorName=daoImpl.getDoctorByName("Roshan");
		assertEquals(getDoctorName1,getDoctorName);
	}

}
