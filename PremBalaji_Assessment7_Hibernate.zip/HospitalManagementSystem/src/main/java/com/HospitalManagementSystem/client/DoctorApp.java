package com.HospitalManagementSystem.client;

public class DoctorApp {

}
