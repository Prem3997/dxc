package com.HospitalManagementSystem.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.HospitalManagementSystem.model.Doctor;
import com.HospitalManagementSystem.util.HibernateUtil;

public class DoctorDaoImpl implements DoctorDao {
	SessionFactory factory=HibernateUtil.getSessionFactory();

	public Doctor getDoctor(String id) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Doctor doctor=(Doctor) session.get(Doctor.class, id);
		
		return doctor;
	}

	public List<Doctor> getAllDoctors() {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Query query=session.createQuery("from Doctor");
		return query.list();
	}

	public boolean addDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		if(isDoctorExists(doctor.getId())) {
			return false;
		}
		else {
			Session session=factory.openSession();
			Transaction transaction=session.beginTransaction();
			session.save(doctor);
			transaction.commit();
			return true;
		}
		
	}

	public boolean deleteDoctor(String id) {
		// TODO Auto-generated method stub
		if(isDoctorExists(id)) {
			Session session=factory.openSession();
			Transaction transaction=session.beginTransaction();
			Doctor doctor=(Doctor) session.get(Doctor.class, id);
			session.delete(doctor);
			transaction.commit();
			return true;
		}else {
			return false;
		}
		
		
	}

	public boolean updateDoctor(Doctor newDoctor) {
		// TODO Auto-generated method stub
		if(isDoctorExists(newDoctor.getId())) {
			Session session=factory.openSession();
			Transaction transaction=session.beginTransaction();
			Doctor oldDoctor=(Doctor) session.get(Doctor.class, newDoctor.getId());
			oldDoctor.setName(newDoctor.getName());
			oldDoctor.setFees(newDoctor.getFees());
			oldDoctor.setDetails(newDoctor.getDetails());
			transaction.commit();
			return true;
		}else {
			return false;
		}
	}

	public boolean isDoctorExists(String id) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Doctor doctor=(Doctor) session.get(Doctor.class, id);
		if(doctor==null)
			return false;
		else
			return true;
	}

	public List<Doctor> getDoctorByName(String doctorName) {
		// TODO Auto-generated method stub
		Session session=factory.openSession();
		Query query=session.createQuery("From Doctor D where D.name='"+doctorName+"'");
		return query.list();
	}

}
