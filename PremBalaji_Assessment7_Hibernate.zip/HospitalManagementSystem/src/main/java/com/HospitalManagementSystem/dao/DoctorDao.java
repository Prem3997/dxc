package com.HospitalManagementSystem.dao;

import java.util.List;

import com.HospitalManagementSystem.model.Doctor;

public interface DoctorDao {
	public Doctor getDoctor(String id);
	public List<Doctor> getAllDoctors();
	public boolean addDoctor(Doctor doctor);
	public boolean deleteDoctor(String id);
	public boolean updateDoctor(Doctor doctor);
	public boolean isDoctorExists(String id);
	public List<Doctor> getDoctorByName(String doctorName);

}
